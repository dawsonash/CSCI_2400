/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_308(unsigned *p)
{
    *p = 2428995913U;
}

void setval_453(unsigned *p)
{
    *p = 1479136808U;
}

unsigned getval_315()
{
    return 3276307258U;
}

void setval_331(unsigned *p)
{
    *p = 2425411658U;
}

unsigned addval_301(unsigned x)
{
    return x + 3284633960U;
}

void setval_314(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_264()
{
    return 3281031256U;
}

unsigned addval_154(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_339(unsigned x)
{
    return x + 3224945289U;
}

void setval_389(unsigned *p)
{
    *p = 3525365449U;
}

void setval_461(unsigned *p)
{
    *p = 1623314057U;
}

unsigned getval_311()
{
    return 3232027017U;
}

void setval_359(unsigned *p)
{
    *p = 3677933193U;
}

unsigned getval_139()
{
    return 3375940105U;
}

unsigned addval_213(unsigned x)
{
    return x + 3758704833U;
}

void setval_241(unsigned *p)
{
    *p = 3223372417U;
}

unsigned addval_222(unsigned x)
{
    return x + 3767093259U;
}

void setval_169(unsigned *p)
{
    *p = 3234120329U;
}

unsigned addval_332(unsigned x)
{
    return x + 3531915977U;
}

unsigned addval_253(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_459()
{
    return 3286280520U;
}

unsigned getval_107()
{
    return 2429651327U;
}

unsigned getval_422()
{
    return 3373846921U;
}

unsigned addval_157(unsigned x)
{
    return x + 3223375561U;
}

unsigned getval_275()
{
    return 3682124425U;
}

unsigned getval_290()
{
    return 3768141987U;
}

unsigned addval_150(unsigned x)
{
    return x + 2227424777U;
}

void setval_228(unsigned *p)
{
    *p = 3523793289U;
}

unsigned getval_367()
{
    return 3682913921U;
}

void setval_383(unsigned *p)
{
    *p = 2428668162U;
}

unsigned getval_242()
{
    return 2430638408U;
}

unsigned getval_121()
{
    return 2277757193U;
}

unsigned addval_137(unsigned x)
{
    return x + 3286272344U;
}

unsigned getval_358()
{
    return 2425671305U;
}

void setval_463(unsigned *p)
{
    *p = 3374371081U;
}

unsigned addval_133(unsigned x)
{
    return x + 3286272328U;
}

void setval_470(unsigned *p)
{
    *p = 2429655387U;
}

void setval_149(unsigned *p)
{
    *p = 3375940297U;
}

unsigned getval_307()
{
    return 2464188744U;
}

unsigned getval_390()
{
    return 3381973385U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
